
tattoo test - v1 tattoo_test
==============================

This dataset was exported via roboflow.ai on March 11, 2022 at 3:37 PM GMT

It includes 48 images.
Tattoo are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


