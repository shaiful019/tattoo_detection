
tattoo_train - v2 train_valid_3x
==============================

This dataset was exported via roboflow.ai on March 11, 2022 at 2:37 PM GMT

It includes 129 images.
Tattoo are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Random rotation of between -15 and +15 degrees


